import { Button } from "@mui/material";
import Navbar from "../components/Navbar";
import Portfoliopage from "../components/Portfoliopage";
import Footer from "../components/Footer";
import Getintouch from "../components/Getintouch";
import RegisterForm from "../components/RegisterForm";
import Aboutus from "../components/Aboutus";
import Ourservice from "../components/Ourservice";
import styles from "./CreativeAgency.module.css";

const CreativeAgency = () => {
  return (
    <div className={styles.creativeAgency}>
      <section className={styles.bgExperience}>
        <img
          className={styles.bgExperienceChild}
          alt=""
          src="/rectangle-15.svg"
        />
        <img
          className={styles.bgExperienceItem}
          alt=""
          src="/rectangle-24.svg"
        />
      </section>
      <Navbar />
      <section className={styles.portfolio} id="past projects">
        <div className={styles.groupParent}>
          <img className={styles.groupIcon} alt="" src="/group.svg" />
          <b className={styles.b}>50+</b>
          <div className={styles.teamMembers}>Team members</div>
        </div>
        <div className={styles.groupGroup}>
          <img className={styles.groupIcon1} alt="" src="/group1.svg" />
          <b className={styles.b}>200+</b>
          <div className={styles.teamMembers}>Project done</div>
        </div>
        <div className={styles.groupContainer}>
          <img className={styles.groupIcon2} alt="" src="/group2.svg" />
          <b className={styles.b}>500+</b>
          <div className={styles.teamMembers}>Happy customers</div>
        </div>
        <div className={styles.frameDiv}>
          <img className={styles.groupIcon3} alt="" src="/group3.svg" />
          <b className={styles.b}>75+</b>
          <div className={styles.teamMembers}>{`Award Winning `}</div>
        </div>
      </section>
      <Portfoliopage />
      <section className={styles.experience} id="experience">
        <div className={styles.loremIpsumNequeContainer}>
          <p className={styles.loremIpsumNeque}>
            Lorem ipsum Neque porro quisquam est qui do lorem ipsum quia dolor
            sit amet, Neque porro elit NeDque porro Lorem ipsum
          </p>
        </div>
        <div className={styles.frameParent}>
          <div className={styles.vectorParent}>
            <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
            <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
            <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
          </div>
          <div className={styles.happyCustomerParent}>
            <div className={styles.happyCustomer}>
              <p className={styles.loremIpsumNeque}>{`Happy Customer `}</p>
            </div>
            <div className={styles.experiencedTeam}>Experienced Team</div>
            <div className={styles.experiencedTeam}>Modern Technology</div>
          </div>
        </div>
        <div className={styles.whyUsParent}>
          <div className={styles.whyUs}>why us?</div>
          <h1 className={styles.yearsOfExperienceContainer}>
            <span>{`25 years of  `}</span>
            <span className={styles.our}>{`experience `}</span>
            <span>as a creative agency</span>
          </h1>
          <Button
            className={styles.groupChild}
            sx={{ width: 175 }}
            color="primary"
            variant="outlined"
          >
            rEAD more
          </Button>
          <img className={styles.groupItem} alt="" src="/line-4.svg" />
        </div>
      </section>
      <section className={styles.clientFeedback}>
        <section className={styles.reviewSlide} id="feedback">
          <div className={styles.heading}>
            <div className={styles.testimonialsWrapper}>
              <div className={styles.testimonials}>TESTIMONIALS</div>
            </div>
            <h1 className={styles.whatOurClientsContainer}>
              <span>{`WHAT `}</span>
              <span className={styles.our}>our</span>
              <span> CLIENTS SAY?</span>
            </h1>
            <div className={styles.headingChild} />
          </div>
          <div className={styles.reviewBox}>
            <div className={styles.reviewBoxChild} />
            <div className={styles.review}>
              <img
                className={styles.reviewChild}
                alt=""
                src="/ellipse-1@2x.png"
              />
              <b className={styles.carolChaves}>Carol Chaves</b>
              <i className={styles.carolesgmailcom}>@caroles.gmail.com</i>
              <div className={styles.coomas}>
                <img className={styles.vectorIcon3} alt="" src="/vector2.svg" />
                <img className={styles.vectorIcon3} alt="" src="/vector3.svg" />
              </div>
              <div className={styles.loremIpsumNequeContainer1}>
                <p
                  className={styles.loremIpsumNeque}
                >{`Lorem ipsum Neque porro quisquam est qui do lorem ipsum quia dolor sit amet,  Neque porro elit `}</p>
                <p className={styles.blankLine}>&nbsp;</p>
              </div>
            </div>
          </div>
          <img className={styles.imageIcon} alt="" src="/image@2x.png" />
          <img className={styles.imageIcon1} alt="" src="/image1@2x.png" />
        </section>
      </section>
      <footer className={styles.footer} id="Footer">
        <div className={styles.copyright20032023}>
          Copyright © 2003-2023 Creatic Agency All rights reserved.
        </div>
        <div className={styles.footerInner}>
          <Footer />
        </div>
      </footer>
      <section className={styles.contactUs}>
        <section className={styles.getInTouch} id="Get in touch">
          <Getintouch />
        </section>
        <RegisterForm />
      </section>
      <Aboutus />
      <Ourservice />
    </div>
  );
};

export default CreativeAgency;
