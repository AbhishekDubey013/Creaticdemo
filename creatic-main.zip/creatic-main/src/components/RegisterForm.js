import {
  TextField,
  InputAdornment,
  Icon,
  IconButton,
  Button,
} from "@mui/material";
import styles from "./RegisterForm.module.css";

const RegisterForm = () => {
  return (
    <main className={styles.register} id="register">
      <div className={styles.registerChild} />
      <div className={styles.yourNameWrapper}>
        <div className={styles.yourName}>YOUR NAME</div>
      </div>
      <div className={styles.yourEmailWrapper}>
        <div className={styles.yourName}>YOUR EMAIL</div>
      </div>
      <div className={styles.yourMessageWrapper}>
        <div className={styles.yourMessage}>YOUR MESSAGE</div>
      </div>
      <TextField
        className={styles.registerItem}
        color="primary"
        sx={{ width: 426 }}
        variant="filled"
      />
      <TextField
        className={styles.registerInner}
        color="primary"
        sx={{ width: 426 }}
        variant="filled"
      />
      <TextField
        className={styles.rectangleTextfield}
        color="primary"
        sx={{ width: 426 }}
        variant="standard"
        multiline
      />
      <Button
        className={styles.frameButton}
        sx={{ width: 188 }}
        color="primary"
        variant="outlined"
      >
        GET IN TOUCH
      </Button>
    </main>
  );
};

export default RegisterForm;
