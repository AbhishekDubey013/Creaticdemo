import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <div className={styles.lineParent}>
      <div className={styles.groupChild} />
      <div
        className={styles.loremIpsumNeque}
      >{`Lorem ipsum Neque porro quisquam est qui do lorem ipsum quia dolor sit amet,  Neque porro elit NeDque   `}</div>
      <div className={styles.logo}>
        <h1 className={styles.creatic}>
          <p className={styles.creatic1}>Creatic</p>
        </h1>
        <div className={styles.creativeAgency}>CREATIVE AGENCY</div>
      </div>
      <div className={styles.frameParent}>
        <div className={styles.categoriesWrapper}>
          <div className={styles.categories}>Categories</div>
        </div>
        <div className={styles.categoriesWrapper}>
          <div className={styles.categories}>About</div>
        </div>
        <div className={styles.categoriesWrapper}>
          <div className={styles.categories}>Services</div>
        </div>
        <div className={styles.categoriesWrapper}>
          <div className={styles.categories}>Portfolio</div>
        </div>
        <div className={styles.categoriesWrapper}>
          <div className={styles.categories}>Pages</div>
        </div>
        <div className={styles.categoriesWrapper}>
          <div className={styles.categories}>Support</div>
        </div>
      </div>
      <div className={styles.lastSlideIcons}>
        <img className={styles.vectorIcon} alt="" src="/vector4.svg" />
        <img className={styles.vectorIcon} alt="" src="/vector5.svg" />
        <img className={styles.vectorIcon2} alt="" src="/vector6.svg" />
        <img className={styles.vectorIcon3} alt="" src="/vector7.svg" />
        <img className={styles.vectorIcon} alt="" src="/vector8.svg" />
        <img className={styles.vectorIcon5} alt="" src="/vector9.svg" />
      </div>
    </div>
  );
};

export default Footer;
