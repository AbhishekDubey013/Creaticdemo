import { Button } from "@mui/material";
import styles from "./Aboutus.module.css";

const Aboutus = () => {
  return (
    <section className={styles.aboutUs}>
      <div className={styles.aboutUs1}>
        <section className={styles.aboutUs2} id="about us">
          <div className={styles.aboutUs3}>ABOUT US</div>
          <h1 className={styles.weBringCreativeContainer}>
            <span>{`We Bring `}</span>
            <span className={styles.creative}>Creative</span>
            <span> ideas to life.</span>
          </h1>
          <img className={styles.aboutUsChild} alt="" src="/line-21.svg" />
          <div className={styles.weLoveCreating}>We love Creating</div>
          <div className={styles.loremIpsumnequePorroContainer}>
            <p
              className={styles.loremIpsumnequePorro}
            >{`Lorem ipsumNeque porro quisquam est qui do lorem ipsum quia dolor sit amet,  Neque porro elit NeDque porro  Lorem ipsum Neque porro Neque porro `}</p>
            <p
              className={styles.nequePorroQuisquam}
            >{`Neque porro quisquam est qui do lorem ipsum quia dolor sit amet,  Lorem ipsum Neque quis ipsum `}</p>
          </div>
          <Button sx={{ width: 175 }} color="primary" variant="outlined">
            GET IN TOUCH
          </Button>
        </section>
        <img
          className={styles.pngtreeartificialIntelligencIcon}
          alt=""
          src="/pngtreeartificial-intelligence-management-system-robot-5339376-1@2x.png"
        />
      </div>
      <img className={styles.imageIcon} alt="" src="/rectangle-3.svg" />
    </section>
  );
};

export default Aboutus;
