import styles from "./Getintouch.module.css";

const Getintouch = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.officeAddressParent}>
        <b className={styles.officeAddress}>Office Address</b>
        <div className={styles.arcaStPr}>
          98, Arca St, PR City, 33414 , Indonesia
        </div>
      </div>
      <div className={styles.callUsParent}>
        <b className={styles.callUs}>Call Us</b>
        <div className={styles.infocreaticagencycom}>(+BK) 123 456 7891</div>
      </div>
      <div className={styles.mailUsParent}>
        <b className={styles.callUs}>Mail Us</b>
        <div className={styles.infocreaticagencycom}>
          info@creaticagency.com
        </div>
      </div>
      <h1 className={styles.getInTouchContainer}>
        <span>Get in</span>
        <span className={styles.touch}> TOUCH</span>
      </h1>
      <img className={styles.groupChild} alt="" src="/line-21.svg" />
      <div
        className={styles.loremIpsumNeque}
      >{`Lorem ipsum Neque porro quisquam est qui do lorem ipsum quia dolor sit amet,  Neque porro elit NeDque porro  `}</div>
      <div className={styles.vectorParent}>
        <img className={styles.vectorIcon} alt="" src="/vector21.svg" />
        <img className={styles.vectorIcon1} alt="" src="/vector31.svg" />
        <img className={styles.gmailIcon} alt="" src="/gmail.svg" />
      </div>
    </div>
  );
};

export default Getintouch;
