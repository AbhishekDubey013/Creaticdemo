import { Button } from "@mui/material";
import styles from "./Navbar.module.css";

const Navbar = () => {
  return (
    <header className={styles.home}>
      <header className={styles.navbar}>
        <nav className={styles.navBar}>
          <div className={styles.homeWrapper}>
            <div className={styles.home1}>Home</div>
          </div>
          <div className={styles.homeWrapper}>
            <div className={styles.aboutUs}>About Us</div>
          </div>
          <div className={styles.homeWrapper}>
            <div className={styles.aboutUs}>Services</div>
          </div>
          <div className={styles.homeWrapper}>
            <div className={styles.aboutUs}>Portfolio</div>
          </div>
          <div className={styles.homeWrapper}>
            <div className={styles.aboutUs}>Pages</div>
          </div>
          <div className={styles.homeWrapper}>
            <div className={styles.aboutUs}>Contact Us</div>
          </div>
          <div className={styles.magnify}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
          </div>
        </nav>
        <section className={styles.logo} id="logo">
          <h1 className={styles.creatic}>
            <p className={styles.creatic1}>Creatic</p>
          </h1>
          <div className={styles.creativeAgency}>CREATIVE AGENCY</div>
        </section>
      </header>
      <section className={styles.welcome} id="welcome">
        <div className={styles.welcomeToCreatic}>Welcome to creatic</div>
        <h1 className={styles.weAreCreativeContainer}>
          <span>{`WE ARE `}</span>
          <span className={styles.creative}>CREATIVE</span>
          <span> DESIGN AGENCY</span>
        </h1>
        <div className={styles.welcomeChild} />
        <div className={styles.loremIpsumnequePorro}>
          Lorem ipsumNeque porro quisquam est qui dolorem ipsum quia dolor sit
          amet, consectetur, adipisci velit Neque porro elit Neque porro quis
          ipsum
        </div>
        <Button sx={{ width: 175 }} color="primary" variant="outlined">
          GET IN TOUCH
        </Button>
      </section>
    </header>
  );
};

export default Navbar;
