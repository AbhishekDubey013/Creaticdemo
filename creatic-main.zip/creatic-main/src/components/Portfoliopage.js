import styles from "./Portfoliopage.module.css";

const Portfoliopage = () => {
  return (
    <section className={styles.pages}>
      <h1 className={styles.enjoyOurLatestContainer}>
        <span className={styles.enjoyOurLatestContainer1}>
          <b>{`ENJOY OUR `}</b>
          <span className={styles.latest}>LATEST</span>
          <b>{` PROJECTS `}</b>
        </span>
      </h1>
      <div className={styles.vectorParent}>
        <img className={styles.groupChild} alt="" src="/line-2.svg" />
        <img className={styles.groupItem} alt="" src="/line-2.svg" />
        <div className={styles.ourWork}>our WORK</div>
      </div>
      <div className={styles.pexelsMotionalStudio1081685Parent}>
        <img
          className={styles.pexelsMotionalStudio1081685Icon}
          alt=""
          src="/pexelsmotionalstudio1081685-1-1@2x.png"
        />
        <img
          className={styles.rm369033a1Icon}
          alt=""
          src="/rm369033a-1@2x.png"
        />
        <img
          className={styles.gradientAiCloudWithBrokenIcon}
          alt=""
          src="/gradientaicloudwithbrokenpieces-1@2x.png"
        />
      </div>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.frameItem} />
        <div className={styles.frameInner} />
        <div className={styles.rectangleDiv} />
        <div className={styles.frameChild1} />
      </div>
    </section>
  );
};

export default Portfoliopage;
