import { Button } from "@mui/material";
import styles from "./Ourservice.module.css";

const Ourservice = () => {
  return (
    <section className={styles.services}>
      <section className={styles.ourService} id="our service">
        <div className={styles.ourServices}>our services</div>
        <h1 className={styles.experienceThePowerContainer}>
          <span>{`Experience the power of `}</span>
          <span className={styles.innovation}>innovation</span>
          <span>.</span>
        </h1>
        <img className={styles.ourServiceChild} alt="" src="/line-21.svg" />
        <div
          className={styles.loremIpsumNeque}
        >{`Lorem ipsum Neque porro quisquam est qui do lorem ipsum quia dolor sit amet,  Neque porro elit NeDque porro  Neque porro quisquam est qui do lorem ipsum quia dolor sit amets ipsum `}</div>
        <Button sx={{ width: 145 }} color="primary" variant="outlined">
          GET IN TOUCH
        </Button>
      </section>
      <div className={styles.services1}>
        <section className={styles.servicesRec} id="service available">
          <div className={styles.servicesRecChild} />
          <div className={styles.servicesRecItem} />
          <div className={styles.servicesRecInner} />
          <div className={styles.rectangleDiv} />
        </section>
        <div className={styles.graphicRec}>
          <img className={styles.graphicIcon} alt="" src="/graphic-icon.svg" />
          <div className={styles.graphicDesignParent}>
            <div className={styles.graphicDesign}>Graphic Design</div>
            <div
              className={styles.loremIpsumNeque1}
            >{`Lorem ipsum Neque do porro quisquam est qui do quam `}</div>
          </div>
        </div>
        <div className={styles.videoRec}>
          <img className={styles.videoIcon} alt="" src="/video-icon.svg" />
          <div className={styles.videoMarketing}>VIDEO MARKETING</div>
          <div
            className={styles.loremIpsumNeque2}
          >{`Lorem ipsum Neque do porro quisquam est qui do quam `}</div>
        </div>
        <div className={styles.webRec}>
          <img className={styles.webIcon} alt="" src="/web-icon.svg" />
          <div className={styles.websiteDesignParent}>
            <div className={styles.graphicDesign}>WEBSITE DESIGN</div>
            <div
              className={styles.loremIpsumNeque1}
            >{`Lorem ipsum Neque do porro quisquam est qui do quam `}</div>
          </div>
        </div>
        <div className={styles.uiuxRec}>
          <img className={styles.iconUiux} alt="" src="/icon-uiux.svg" />
          <div className={styles.graphicDesignParent}>
            <div className={styles.graphicDesign}>ui/ux Design</div>
            <div
              className={styles.loremIpsumNeque1}
            >{`Lorem ipsum Neque do porro quisquam est qui do quam `}</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Ourservice;
